# 2.5.2 추가 리소스 출처
- Mythical Staff — Kindred408: https://www.planetminecraft.com/data-pack/mythical-staff-datapack/
- Bows to Magic Staves CIT 1.7 — nongko: https://www.planetminecraft.com/texture-pack/transform-bows-to-staves-mystic-staves-addon-12-unique-3d-models/
  원본 그림은 유지하고 3종만 바닐라 item_model로 연결했습니다. OptiFine 불필요.
- Wither's Wrath 1.16 / RP 2.0 — ImHer0: https://modrinth.com/datapack/witherswrath · https://modrinth.com/resourcepack/withers-wrath-rp
  CC BY-NC 4.0: https://github.com/ImHer0/witherswrath/blob/main/LICENSE
  서버 호환 변경: 지형 직접 파괴·화재 확산·날씨 변경 차단, 로드시 위더 강제 삭제 제거. 음악과 트로피 모델 원형 유지.
